#include <windows.h>
#include <assert.h>
#include <string>
#include <time.h>
#include <iostream>

BOOL SaveBitmapToFile(HBITMAP hBitmap, std::string szfilename) {
	HDC hDC;
	int iBits;
	WORD wBitCount;
	DWORD dwPaletteSize= 0, dwBmBitsSize= 0, dwDIBSize= 0, dwWritten= 0;
	BITMAP Bitmap;
	BITMAPFILEHEADER bmfHdr;
	BITMAPINFOHEADER bi;
	LPBITMAPINFOHEADER lpbi;
	HANDLE fh, hDib, hPal, hOldPal= NULL;

	hDC= CreateDCA("DISPLAY", NULL, NULL, NULL);
	iBits= GetDeviceCaps(hDC, BITSPIXEL) * GetDeviceCaps(hDC, PLANES);
	DeleteDC(hDC);
	if(iBits <= 1)
		wBitCount= 1;
	else if(iBits <= 4)
		wBitCount= 4;
	else if(iBits <= 8)
		wBitCount= 8;
	else
		wBitCount= 24;

	GetObject(hBitmap, sizeof(Bitmap), (LPSTR)&Bitmap);
	bi.biSize= sizeof(BITMAPINFOHEADER);
	bi.biWidth= Bitmap.bmWidth;
	bi.biHeight= Bitmap.bmHeight;
	bi.biPlanes= 1;
	bi.biBitCount= wBitCount;
	bi.biCompression= BI_RGB;
	bi.biSizeImage= 0;
	bi.biXPelsPerMeter= 0;
	bi.biYPelsPerMeter= 0;
	bi.biClrImportant= 0;
	bi.biClrUsed= 0;

	dwBmBitsSize= ((Bitmap.bmWidth * wBitCount + 31) / 32) * 4 * Bitmap.bmHeight;

	hDib= GlobalAlloc(GHND, dwBmBitsSize + dwPaletteSize + sizeof(BITMAPINFOHEADER));
	lpbi= (LPBITMAPINFOHEADER)GlobalLock(hDib);
	*lpbi= bi;

	hPal= GetStockObject(DEFAULT_PALETTE);
	if(hPal) {
		hDC= ::GetDC(NULL);
		hOldPal= ::SelectPalette(hDC, (HPALETTE)hPal, FALSE);
		RealizePalette(hDC);
	}

	GetDIBits(hDC, hBitmap, 0, (UINT)Bitmap.bmHeight, (LPSTR)lpbi + sizeof(BITMAPINFOHEADER) + dwPaletteSize, (BITMAPINFO *)lpbi, DIB_RGB_COLORS);

	if(hOldPal) {
		::SelectPalette(hDC, (HPALETTE)hOldPal, TRUE);
		RealizePalette(hDC);
		::ReleaseDC(NULL, hDC);
	}

	fh= CreateFileA(szfilename.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN, NULL);

	if(fh == INVALID_HANDLE_VALUE) return FALSE;

	bmfHdr.bfType= 0x4D42;
	dwDIBSize= sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + dwPaletteSize + dwBmBitsSize;
	bmfHdr.bfSize= dwDIBSize;
	bmfHdr.bfReserved1= 0;
	bmfHdr.bfReserved2= 0;
	bmfHdr.bfOffBits= (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER) + dwPaletteSize;
	WriteFile(fh, (LPSTR)&bmfHdr, sizeof(BITMAPFILEHEADER), &dwWritten, NULL);
	WriteFile(fh, (LPSTR)lpbi, dwDIBSize, &dwWritten, NULL);
	GlobalUnlock(hDib);
	GlobalFree(hDib);
	CloseHandle(fh);

	return TRUE;
}
int save;
void CaptureScreen() {
	int nScreenWidth= GetSystemMetrics(SM_CXSCREEN);
	int nScreenHeight= GetSystemMetrics(SM_CYSCREEN);
	HWND hDesktopWnd= GetDesktopWindow();
	HDC hDesktopDC= GetDC(hDesktopWnd);
	HDC hCaptureDC= CreateCompatibleDC(hDesktopDC);
	HBITMAP hCaptureBitmap= CreateCompatibleBitmap(hDesktopDC, nScreenWidth, nScreenHeight);
	SelectObject(hCaptureDC, hCaptureBitmap);
	BitBlt(hCaptureDC, 0, 0, nScreenWidth, nScreenHeight, hDesktopDC, 0, 0, SRCCOPY);
	if(save) SaveBitmapToFile(hCaptureBitmap, "./now.bmp"); 
	ReleaseDC(hDesktopWnd, hDesktopDC);
	DeleteDC(hCaptureDC);
	DeleteObject(hCaptureBitmap);
}
int main() {
	int n;
	std::cin >> save >> n;
    int bt= clock(), cnt= 0;
    while(clock() - bt < n * 1000) CaptureScreen(), ++cnt;
    std::cout << (double)cnt / n << std::endl;
    getchar(), getchar();
	return 0;
}
