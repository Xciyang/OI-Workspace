var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var partials = require('express-partials');
var schedule = require('node-schedule');
var moment = require('moment');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');
var roomsRouter = require('./routes/rooms');
var buildingsRouter = require('./routes/buildings');
var tasksRouter = require('./routes/tasks');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(partials());

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser("CiyangNB"));
app.use(express.static(path.join(__dirname, 'public')));

(function () {
  usersRouter.init();
  roomsRouter.init();
  buildingsRouter.init();
  tasksRouter.init();
})();

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/rooms', roomsRouter);
app.use('/buildings', buildingsRouter);
app.use('/tasks', tasksRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

const AutoSave = schedule.scheduleJob('0 * * * * *', function () {
  console.log('[' + moment().format('MM-DD HH:mm:ss') + ']' + ' AutoSave begin.');
  usersRouter.save();
  roomsRouter.save();
  buildingsRouter.save();
  console.log('[' + moment().format('MM-DD HH:mm:ss') + ']' + ' AutoSave end.');

});

const TasksStart = schedule.scheduleJob('30 * * * * *', function () {
  console.log('[' + moment().format('MM-DD HH:mm:ss') + ']' + ' Tasks start.');
  tasksRouter.start();
  console.log('[' + moment().format('MM-DD HH:mm:ss') + ']' + ' Tasks finish.');
});

module.exports = app;
