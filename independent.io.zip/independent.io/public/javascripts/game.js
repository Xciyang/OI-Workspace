var GameMain = {
    roomMap: {},
    userMap: {},
    Items: [],
    userImg: []
};

class Item {
    constructor(sImg, cName, eName, sDec, aFeat = {}) {
        this.Img = new Image(), this.Img.src = sImg;
        this.Name = cName, this.NameEn = eName, this.Dec = sDec, this.Feat = aFeat;
    }
}

GameMain.Init = function () {
    GameMain.itemHTML = GameMain.userHTML = GameMain.buildHTML = '';
    var progress = document.getElementById('progress');
    GameMain.canves = document.getElementById('mapCanvas');
    GameMain.cxt = GameMain.canves.getContext("2d");
    GameMain.Items.push(new Item("https://s2.ax1x.com/2019/08/27/m5K1PK.png", "平地", "air", "可以放置建筑。", { canMove: 1 }));
    GameMain.Items.push(new Item("https://s2.ax1x.com/2019/08/27/mhvhxe.png", "泥土", "dirt", "没什么用，好像可以挖。"));
    GameMain.Items.push(new Item("https://s2.ax1x.com/2019/08/27/m5dHVf.png", "石头", "stone", "没什么用，可以随机变成其他物质。"));
    GameMain.Items.push(new Item("https://s2.ax1x.com/2019/08/27/m5OZUP.png", "床", "bed", "保护玩家生命的最后一道防线。", { canBuild: 1 }));

    for (var i = 0; i < GameMain.Items.length; i++) {
        if (GameMain.Items[i].Img.complete) {
            progress.children[0].value += parseInt(100 / GameMain.Items.length) + 1;
            if (progress.children[0].value >= 100) GameMain.Init2();
            continue;
        }
        GameMain.Items[i].Img.onload = function () {
            progress.children[0].value += parseInt(100 / GameMain.Items.length) + 1;
            if (progress.children[0].value >= 100) GameMain.Init2();
        }
    }

    return;
}

GameMain.Init2 = function () {
    var progress = document.getElementById('progress');
    progress.children[0].value = 0;
    GameMain.userImg.push(new Image()), GameMain.userImg[0].src = "https://s2.ax1x.com/2019/08/27/m5vJUI.png";
    GameMain.userImg.push(new Image()), GameMain.userImg[1].src = "https://s2.ax1x.com/2019/08/27/m5vGVA.png";
    for (var i = 0; i < GameMain.userImg.length; i++) {
        if (GameMain.userImg[i].complete) {
            progress.children[0].value += parseInt(100 / GameMain.userImg.length) + 1;
            if (progress.children[0].value >= 100) progress.style.display = "none", GameMain.updateMap();
            continue;
        }
        GameMain.userImg[i].onload = function () {
            progress.children[0].value += parseInt(100 / GameMain.userImg.length) + 1;
            if (progress.children[0].value >= 100) progress.style.display = "none", GameMain.updateMap();
        }
    }
    GameMain.updateMap();
}

GameMain.updateMap = function () {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/rooms/" + GameMain.room, true);
    xhr.onload = function (e) {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                GameMain.roomMap = JSON.parse(xhr.responseText);
                // TODO : Draw ~
                for (var i = 0; i < 20; i++) {
                    for (var j = 0; j < 20; j++) {
                        GameMain.cxt.drawImage(GameMain.Items[GameMain.roomMap.block[i][j]].Img, i * 50, j * 50, 50, 50);
                        GameMain.cxt.strokeStyle = "black", GameMain.cxt.strokeRect(i * 50, j * 50, 50, 50);
                    }
                }
                GameMain.updateUserMap();
                return;
            }
            document.body.innerHTML = "", document.write(xhr.statusText);
        }
    };
    xhr.send(null);
    return;
}

GameMain.updateUserMap = function () {
    for (var i = 0; i < GameMain.roomMap.player.length; i++) {
        if (GameMain.roomMap.player[i] == GameMain.username) {
            GameMain.inUserRoom = 1;
            continue;
        }
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "/users/" + GameMain.roomMap.player[i], true);
        xhr.onload = function (e) {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    GameMain.userMap[GameMain.roomMap.player[i]] = JSON.parse(xhr.responseText);
                    GameMain.cxt.drawImage(GameMain.userImg[0], GameMain.userMap[GameMain.roomMap.player[i]].position.x * 50, GameMain.userMap[GameMain.roomMap.player[i]].position.y * 50, 50, 50);
                    return;
                }
                document.body.innerHTML = "", document.write(xhr.statusText);
            }
        };
        xhr.send(null);
    }
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/users/" + GameMain.username, true);
    xhr.onload = function (e) {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                GameMain.userMap[GameMain.username] = JSON.parse(xhr.responseText);
                if (GameMain.inUserRoom) GameMain.cxt.drawImage(GameMain.userImg[1], GameMain.userMap[GameMain.username].position.x * 50, GameMain.userMap[GameMain.username].position.y * 50, 50, 50);
                GameMain.updatePerson(GameMain.username), GameMain.updateBuild();
                return;
            }
            document.body.innerHTML = "", document.write(xhr.statusText);
        }
    };
    xhr.send(null);
}

GameMain.clickMap = function (event) {
    var x = parseInt((event.clientX + GameMain.canves.parentElement.scrollLeft + 5) / 50) - 1;
    var y = parseInt((event.clientY + GameMain.canves.parentElement.scrollTop + 5) / 50) - 1;
    if (GameMain.lastx != null) GameMain.cxt.strokeStyle = "black", GameMain.cxt.strokeRect(GameMain.lastx * 50, GameMain.lasty * 50, 50, 50), GameMain.cxt.strokeRect(GameMain.lastx * 50, GameMain.lasty * 50, 50, 50);
    GameMain.lastx = x, GameMain.lasty = y;
    GameMain.cxt.strokeStyle = "white", GameMain.cxt.strokeRect(x * 50, y * 50, 50, 50);
    GameMain.updateItem(GameMain.roomMap.block[x][y], { x: x, y: y });
    if (GameMain.showTap != null) {
        switch (GameMain.showTap.id) {
            case 'user-tap': {
                for (var i = 0; i < GameMain.roomMap.player.length; i++)
                    if (x == GameMain.userMap[GameMain.roomMap.player[i]].position.x && y == GameMain.userMap[GameMain.roomMap.player[i]].position.y) updatePerson(GameMain.roomMap.player[i]);
                break;
            }
            case 'build-tap': {
                if(document.getElementsByClassName('buildtap-show').length){
                    console.log(GameMain.nowBuild);
                }
            }
            default: break;
        }
    }

    return;
}

GameMain.checkTwice = function (str) {
    if (str) return window.confirm(str + "，您确定要这样做吗？");
    return window.confirm("您确定要这样做吗？");
}

GameMain.moveTasks = function (position) {
    var ex = GameMain.userMap[GameMain.username].position.x, ey = GameMain.userMap[GameMain.username].position.y;
    var qu = [position], moves = [[-1, 0], [0, -1], [0, 1], [1, 0]], walkpast = new Array(405);
    while (qu.length) {
        var nowp = qu[0], nxp = {}; qu.shift();
        for (var i = 0; i < 4; i++) {
            nxp.x = nowp.x + moves[i][0], nxp.y = nowp.y + moves[i][1];
            if (nxp.x < 0 || nxp.y < 0 || nxp.x > 19 || nxp.y > 19 || walkpast[nxp.x * 20 + nxp.y]) continue;
            if (!GameMain.Items[GameMain.roomMap.block[nxp.x][nxp.y]].Feat.canMove) continue;
            if (nxp.x == ex && nxp.y == ey) {
                console.log(i);
                break;
            }
            walkpast[nxp.x * 20 + nxp.y] = 1, qu.push(nxp);
        }
    }
    return;
}

GameMain.updateItem = function (id, position) {
    if (id != null && GameMain.Items[id]) {
        GameMain.itemHTML = '';
        GameMain.itemHTML += '<p> 名称：' + GameMain.Items[id].Name + ' </p>';
        GameMain.itemHTML += '<p> Name：' + GameMain.Items[id].NameEn + ' </p>';
        GameMain.itemHTML += '<p> 简介：' + GameMain.Items[id].Dec + ' </p>';
        if (GameMain.Items[id].Feat) {
        }
        //if (GameMain.inUserRoom) GameMain.itemHTML += '<button onclick = \"GameMain.moveTasks({x:' + position.x + ',y:' + position.y + '})\"> 移动 </button>'
    }
    if (GameMain.showTap != null && GameMain.showTap.id == 'item-tap') document.getElementById('choosecontent').innerHTML = GameMain.itemHTML;
    return;
}

GameMain.updatePerson = function (name) {
    if (name && GameMain.userMap[name]) {
        GameMain.userHTML = '';
        GameMain.userHTML += '<p> 名称：' + name + ' </p>';
        GameMain.userHTML += '<p> 等级：' + GameMain.userMap[name].level + ' </p>';
        if (GameMain.userMap[name].exp) GameMain.userHTML += '<p> 经验：' + GameMain.userMap[name].exp + ' </p>';
        if (GameMain.userMap[name].hungry) GameMain.userHTML += '<p> 饱食：' + GameMain.userMap[name].hungry + ' % </p>';
        GameMain.userHTML += '<p> 坐标：( ' + GameMain.userMap[name].position.x + ' , ' + GameMain.userMap[name].position.y + ' ) </p>';
        GameMain.userHTML += '<p> 上次活动：' + GameMain.userMap[name].logintime + ' </p>';
        GameMain.userHTML += '<p> 注册时间：' + GameMain.userMap[name].regtime + ' </p>';
    }
    if (GameMain.showTap != null && GameMain.showTap.id == 'user-tap') document.getElementById('choosecontent').innerHTML = GameMain.userHTML;

    return;
}

GameMain.switchBuild = function (id, doc) {
    GameMain.nowBuild = id;
    var show = document.getElementsByClassName('buildtap-show');
    for (var i = 0; i < show.length; i++) show[i].className = 'buildtap';
    doc.className = 'buildtap buildtap-show';
    return;
}

GameMain.updateBuild = function () {
    GameMain.buildHTML = '';
    for (var i = 0; i < GameMain.Items.length; i++) {
        if (GameMain.Items[i].Feat.canBuild || GameMain.userMap[GameMain.username].admin) {
            GameMain.buildHTML += '<div class = \"buildtap\"onclick = GameMain.switchBuild(' + i + ',this) > ';
            GameMain.buildHTML += '<img width=\"64\" height=\"64\" src=\"' + GameMain.Items[i].Img.src + '\"></img>';
            if (GameMain.userMap[GameMain.username].building[GameMain.Items[i].NameEn] == undefined) {
                GameMain.buildHTML += '<p> 未建筑 </p>';
            } else {
                GameMain.buildHTML += '<p> 已建筑：' + GameMain.userMap[GameMain.username].building[GameMain.Items[i].NameEn].length + ' </p>';
            }
            GameMain.buildHTML += '</div>'
        }
    }
    if (GameMain.showTap != null && GameMain.showTap.id == 'build-tap') document.getElementById('choosecontent').innerHTML = GameMain.buildHTML;

    return;
}
function tapSwitch(tap) {
    GameMain.showTap = tap;
    var tapShow = document.getElementsByClassName('tap-show');
    for (var i = 0; i < tapShow.length; i++) tapShow[i].className = "tap";
    tap.className = "tap tap-show";
    switch (tap.id) {
        case 'item-tap': document.getElementById('choosecontent').innerHTML = GameMain.itemHTML; break;
        case 'user-tap': document.getElementById('choosecontent').innerHTML = GameMain.userHTML; break;
        case 'build-tap': document.getElementById('choosecontent').innerHTML = GameMain.buildHTML; break;
    }
    return;
}