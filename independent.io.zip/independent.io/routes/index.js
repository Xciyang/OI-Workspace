var express = require('express');
var cookieParser = require('cookie-parser');
var users = require('./users');
var rooms = require('./rooms');
var buildings = require('./buildings');
var tasks = require('./tasks');

var router = express.Router();

/* GET home page. */
router.get('/', function (req, res, next) {
  return res.render('index', {});
});


router.get('/start', function (req, res, next) {
  var user_name = req.cookies.name;
  if (user_name == undefined || user_name.length == 0) {
    res.cookie('name', '', { expires: new Date(0) });
    res.cookie('pw', '', { expires: new Date(0) });
    return res.render('login', { message: "请先登录或注册。" });
  }
  var user = users.getUser(user_name);
  if (user == null || req.cookies.pw != user.password) {
    res.cookie('name', '', { expires: new Date(0) });
    res.cookie('pw', '', { expires: new Date(0) });
    return res.render('login', { message: "您的身份过期。" });
  }
  if (user.room == 0) return res.redirect('/rooms');
  var utime = (90 - new Date().getSeconds()) % 60;
  if (req.query.room != undefined) return res.render('game', { room: req.query.room, username: user.name, admin: user.admin_user, time: utime });
  return res.render('game', { room: user.room, username: user.name, admin: user.admin_user, time: utime });
});

router.get('/login', function (req, res, next) {
  var user = req.cookies.name;
  if (user) return res.redirect('/start');
  return res.render('login');
});

router.get('/logout', function (req, res, next) {
  res.cookie('name', '', { expires: new Date(0) });
  res.cookie('pw', '', { expires: new Date(0) });
  return res.render('login');
});

router.post('/login', function (req, res, next) {
  var name = req.body.user_name, password = req.body.user_password, twpassword = req.body.user_twiceword, way = req.body.way;
  if (way != 'Login' && way != 'Register') return res.render('login', { message: '您的登录方式有误。', user_name: name, user_password: password });
  try {
    users.JudgeUser(name, password, way);
  } catch (e) {
    return res.render('login', { message: e.message, user_name: name, user_password: password });
  }
  if (way == 'Register') {
    if (password != twpassword) return res.render('login', { message: '两次输入的密码不一致。', user_name: name, user_password: password });
    users.CreateUser(name, password);
    return res.render('login', { message: '你好像还得再登录一下。', user_name: name, user_password: password });
  }
  var user = users.getUser(name);
  if (!user || !users.JudgePassword(password, user)) return res.render('login', { message: '用户名或密码错误。', user_name: name, user_password: password });
  res.cookie('name', name, { maxAge: 3600000, httpOnly: true });
  res.cookie('pw', user.password, { maxAge: 3600000, httpOnly: true });
  return res.redirect('/start');
});

router.get('/stop', function (req, res, next) {
  var user_name = req.cookies.name;
  if (user_name == undefined || user_name.length == 0) {
    res.cookie('name', '', { expires: new Date(0) });
    res.cookie('pw', '', { expires: new Date(0) });
    return res.render('login', { message: "请先登录或注册。" });
  }
  var user = users.getUser(user_name);
  if (user == null || req.cookies.pw != user.password) {
    res.cookie('name', '', { expires: new Date(0) });
    res.cookie('pw', '', { expires: new Date(0) });
    return res.render('login', { message: "您的身份过期。" });
  }
  if (!user.admin_user) return res.redirect('/start');
  users.save(), rooms.save(), buildings.save(), tasks.save();
  process.exit(0);
});

module.exports = router;
