var express = require('express');
var fs = require('fs');
var moment = require('moment');
var crypto = require('crypto');

var router = express.Router();

var users_json;

router.JudegeWord = function (x) {
  return (x < 'a' || x > 'z') && (x < 'A' || x > 'Z') && (x < '0' || x > '9') && x != '_';
}

router.init = function () {
  try {
    var result = fs.readFileSync('./database/users.json');
  } catch (e) {
    console.error(e);
  }
  users_json = JSON.parse(result);
  return;
}

router.save = function () {
  var flag = 1;
  try {
    fs.writeFileSync('./database/users.json', JSON.stringify(users_json));
  } catch (e) {
    flag = 0;
    console.error(e);
  }
  if (flag) console.log('users.json saved.');
}

router.MakePassword = function (password) {
  var md5 = crypto.createHash('md5');
  md5.update(password);
  return md5.digest('hex');
}

router.JudgePassword = function (password, user) {
  return router.MakePassword(password) == user.password;
}

router.JudgeUser = function (name, password, way) {
  if (name == undefined || name.length == 0) throw new Error("无效的用户名。");
  for (var p = 0; p < name.length; p++)
    if (router.JudegeWord(name[p])) throw new Error("用户名中含有非法字符。");
  if (way == 'Login') {
    if (fs.existsSync('./database/user/' + name + '.json') == 0) throw new Error("用户名不存在，请先注册。");
  }
  else if (way == 'Register') {
    if (fs.existsSync('./database/user/' + name + '.json')) throw new Error("用户名已存在，请更换用户名。");
  }
  if (password == undefined) throw new Error("无效的密码。");
  if (password.length < 6) throw new Error("密码长度小于6。");
  for (var p = 0; p < password.length; p++)
    if (router.JudegeWord(password[p])) throw new Error("密码中含有非法字符");
  return;
}

router.CreateUser = function (name, pw) {
  if (fs.existsSync('./database/user/' + name + '.json')) return null;
  var user = router.updateUser(null);
  user.id = users_json.idnow++
  user.name = name;
  user.password = router.MakePassword(pw);
  fs.writeFileSync('./database/user/' + name + '.json', JSON.stringify(user));
  users_json.list[user.id] = name;
  console.log('A user created, name : ' + name + ' , id : ' + user.id + ' .');
  return user;
}

router.getUser = function (name) {
  if (fs.existsSync('./database/user/' + name + '.json') == 0) return null;
  var result = JSON.parse(fs.readFileSync('./database/user/' + name + '.json'));
  return result;
};

router.saveUser = function (user) {
  if (user == undefined) return;
  if (fs.existsSync('./database/user/' + user.name + '.json') == 0) return null;
  fs.writeFileSync('./database/user/' + user.name + '.json', JSON.stringify(user));
  return user;
};

router.updateUser = function (user) {
  if (user == null)
    return {
      version: 2.0,
      position: { x: 0, y: 0 },
      room: 0,
      regtime: moment().format('MM-DD HH:mm:ss'),
      logintime: '',
      hungry: 100,
      heal: 100,
      money: 0,
      name: '',
      id: 0,
      password: '',
      level: 1,
      exp: 0,
      admin_user: 0,
      building: {}
    };

  user.logintime = moment().format('MM-DD HH:mm:ss');
  var lversion = user.version;
  user.version = 2.0;
  // TODO : version 2.0
  user.building = {};
  // TODO : version 1.5
  if (lversion >= 1.5) return;
  user.hungry = 100;
  user.money = 100;
  user.heal = 100;
  // TODO : version 1.0 (olddest)
  return;
}

router.updateLevel = function (user) {
  if (user == null || user.level == null) return null;
  while (user.level < users_json.exp.length && user.exp > users_json.exp[user.level]) {
    user.exp -= users_json.exp[user.level];
    user.level++;
  }
  return user;
}
/* GET users listing. */
router.get('/', function (req, res, next) {
  res.send('web is developing.');
});

router.get('/:name', function (req, res, next) {
  var user_name = req.cookies.name;
  if (user_name == undefined || user_name.length == 0) {
    res.cookie('name', '', { expires: new Date(0) });
    res.cookie('pw', '', { expires: new Date(0) });
    return res.render('login', { message: "请先登录或注册。" });
  }
  var user = router.getUser(user_name);
  if (user == null || req.cookies.pw != user.password) {
    res.cookie('name', '', { expires: new Date(0) });
    res.cookie('pw', '', { expires: new Date(0) });
    return res.render('login', { message: "您的身份过期。" });
  }
  router.updateUser(user), router.saveUser(user);
  if (req.params.name == user_name) return res.send({
    name: user.name,
    level: user.level,
    exp: user.exp,
    logintime: user.logintime,
    regtime: user.regtime,
    hungry: user.hungry,
    room: user.room,
    position: user.position,
    building: user.building,
    admin: user.admin_user
  });
  var result = router.getUser(req.params.name);
  if (user == null) res.send('Name Error');
  return res.send({ name: result.name, level: result.level, logintime: result.logintime, regtime: result.regtime });
});
module.exports = router;
