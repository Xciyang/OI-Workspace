var express = require('express');
var fs = require('fs');

var router = express.Router();

var tasks_json, task_start;
router.init = function () {
    try {
        var result = fs.readFileSync('./database/tasks.json');
    } catch (e) {
        console.error(e);
    }
    tasks_json = JSON.parse(result);
    return;
}

router.save = function () {
    var flag = 1;
    try {
        fs.writeFileSync('./database/tasks.json', JSON.stringify(tasks_json));
    } catch (e) {
        flag = 0;
        console.error(e);
    }
    if (flag) console.log('tasks.json saved.');
}

router.start = function () {
    task_start = 1;
}


module.exports = router;