var express = require('express');
var fs = require('fs');
var users = require('./users');
var router = express.Router();

var rooms_json;

// router.first = function () {
//     var WORD = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//     for (var i = 0; i < 6; i++) {
//         for (var j = 0; j < 6; j++) {
//             var room = router.getRoom(WORD[i] + j);
//             room.player = [];
//             router.saveRoom(room);
//         }
//     }
// }

router.init = function () {
    try {
        var result = fs.readFileSync('./database/rooms.json');
    } catch (e) {
        console.error(e);
    }
    rooms_json = JSON.parse(result);
    return;
}

router.save = function () {
    var flag = 1;
    try {
        fs.writeFileSync('./database/rooms.json', JSON.stringify(rooms_json));
    } catch (e) {
        flag = 0;
        console.error(e);
    }
    if (flag) console.log('rooms.json saved.');
}

router.getRoom = function (name) {
    if (name == undefined || name.length != 2 || fs.existsSync('./database/room/' + name + '.json') == 0) return null;
    return JSON.parse(fs.readFileSync('./database/room/' + name + '.json'));
}

router.saveRoom = function (room) {
    if (room == undefined) return null;
    if (fs.existsSync('./database/room/' + room.name + '.json') == 0) return null;
    fs.writeFileSync('./database/room/' + room.name + '.json', JSON.stringify(room));
    return room;
}

router.get('/', function (req, res, next) {
    var user_name = req.cookies.name;
    if (user_name == undefined || user_name.length == 0) {
        res.cookie('name', '', { expires: new Date(0) });
        res.cookie('pw', '', { expires: new Date(0) });
        return res.render('login', { message: "请先登录或注册。" });
    }
    var user = users.getUser(user_name);
    if (user == null || req.cookies.pw != user.password) {
        res.cookie('name', '', { expires: new Date(0) });
        res.cookie('pw', '', { expires: new Date(0) });
        return res.render('login', { message: "您的身份过期。" });
    }
    if (!user.room) return res.render('rooms', { choose: 1 });
    return res.render('rooms', {});
});

router.post('/', function (req, res, next) {
    var opt = req.body.opt;
    if (opt == 1) {
        var result = router.getRoom(req.body.roomid);
        if (result == null) return res.send('ID Error');
        return res.send({ level: result.level, home: result.home });
    }
    var user_name = req.cookies.name;
    if (user_name == undefined || user_name.length == 0) {
        res.cookie('name', '', { expires: new Date(0) });
        res.cookie('pw', '', { expires: new Date(0) });
        return res.render('login', { message: "请先登录或注册。" });
    }
    var user = users.getUser(user_name);
    if (user == null || req.cookies.pw != user.password) {
        res.cookie('name', '', { expires: new Date(0) });
        res.cookie('pw', '', { expires: new Date(0) });
        return res.render('login', { message: "您的身份过期。" });
    }
    if (opt == 2) {
        var result = router.getRoom(req.body.roomid);
        if (result == null) return res.send('ID Error');
        if (result.level > 2) return res.render('rooms', { choose: 1, message: "房间等级太高。" });
        user.room = req.body.roomid, users.updateUser(user), users.saveUser(user);
        return res.redirect('/start');
    }
    return res.send('Operation Error');
});

router.get('/:id', function (req, res, next) {
    var user_name = req.cookies.name;
    if (user_name == undefined || user_name.length == 0) {
        res.cookie('name', '', { expires: new Date(0) });
        res.cookie('pw', '', { expires: new Date(0) });
        return res.redirect('/login');
    }
    var user = users.getUser(user_name);
    if (user == null || req.cookies.pw != user.password) {
        res.cookie('name', '', { expires: new Date(0) });
        res.cookie('pw', '', { expires: new Date(0) });
        return res.redirect('/login');
    }
    var result = router.getRoom(req.params.id);
    if (result == null) return res.send('ID Error');
    return res.send(result);
});
module.exports = router;
