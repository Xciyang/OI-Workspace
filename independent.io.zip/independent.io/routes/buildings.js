var express = require('express');
var fs = require('fs');

var router = express.Router();

var buildings_json;

router.init = function () {
    try {
        var result = fs.readFileSync('./database/buildings.json');
    } catch (e) {
        console.error(e);
    }
    buildings_json = JSON.parse(result);
    return;
}

router.save = function () {
    var flag = 1;
    try {
        fs.writeFileSync('./database/buildings.json', JSON.stringify(buildings_json));
    } catch (e) {
        flag = 0;
        console.error(e);
    }
    if (flag) console.log('buildings.json saved.');
}

router.createBuilding = function (name, user, position) {
    if (fs.existsSync('./database/building/' + name + '.json')) return null;
    var building = router.updateBuilding(null);
    building.id = buildings_json.idnow++
    building.name = name;
    building.position = position;
    building.owner = user.name;
    building.room = user.room;
    fs.writeFileSync('./database/user/' + name + '.json', JSON.stringify(user));
    buildings_json.list[building.id] = user.name;
    console.log('A building created, name : ' + name + ' , user : ' + user.name + ' .');
    return building;
}

router.updateBuilding = function (building) {
    if (building == null) return {
        version: 1.0,
        owner: '',
        position: { x: 0, y: 0 },
        room: 0,
        id: 0,
        buildtime: moment().format('MM-DD HH:mm:ss'),
        level: 1,
        name: '',
        damage: 0,
        exp: 0
    };
}

router.get('/', function (req, res, next) {
    res.send('web is developing.');
});

module.exports = router;