#include<cstdio>
#include<iostream>
#include<ctime>
#include<string>
#include<map>
#define N 30
using namespace std;
int cnt,ma[6][6];
bool vis[N];
char temp[N],opt[N];
string res[50005],s;
map<string,int>ans2;
void dfs(int id)
{
	if(id>25)
	{
		cnt++;
		for(int i=0;i<25;i++)res[cnt]+=temp[i];
		ans2[res[cnt]]=cnt;
		return;
	}
	int x,y;
	if(id%5)x=id/5+1,y=id%5;
	else x=id/5,y=5;
	for(int i=0;i<25;i++)
		if(!vis[i]&&(x==1||ma[x-1][y]<i)&&(y==1||ma[x][y-1]<i))
		{
			vis[i]=1;
			ma[x][y]=i;
			temp[id-1]=i+'A';
			dfs(id+1);
			if(cnt>=(int)25000)break;
			vis[i]=0;
		}
}
int main()
{
	freopen("twofive.in","r",stdin);
	freopen("twofive.out","w",stdout);
	dfs(1);
	scanf("%s",opt);
	if(opt[0]=='W')
	{
		scanf("%s",temp);
		for(int i=0;i<25;i++)s+=temp[i];
		printf("%d\n",ans2[s]);
	}
	else
	{
		int x;
		scanf("%d",&x);
		cout<<res[x]<<endl;
	}
	return 0;
}
/*
ABCDEFGHIJKLMNOPQRSTUVWXY
ABCDEFGHIJKLMNOPQRSUTVWXY
A B C D E
F G H I J
K L M N O
P Q R S T
U V W X Y
*/
