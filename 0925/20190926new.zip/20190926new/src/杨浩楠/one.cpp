#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<ctime>
#define N 1000005
#define il inline
using namespace std;
int T,n,s,cnt,rt;
struct BST
{
	int lc,rc,size,v,pri;
}t[N];
il void up(int x)
{
	t[x].size=t[t[x].lc].size+t[t[x].rc].size+1;
}
il void zig(int &x)
{
	int y=t[x].lc;
	t[x].lc=t[y].rc;
	t[y].rc=x;
	up(x),up(y);
	x=y;
}
il void zag(int &x)
{
	int y=t[x].rc;
	t[x].rc=t[y].lc;
	t[y].lc=x;
	up(x),up(y);
	x=y;
}
void Insert(int &x,int v)
{
	if(!x)
	{
		x=++cnt;
		t[x]=(BST){0,0,1,v,rand()*rand()};
		return;
	}
	t[x].size++;
	if(v<t[x].v)
	{
		Insert(t[x].lc,v);
		if(t[t[x].lc].pri>t[x].pri)zig(x);
	}
	else
	{
		Insert(t[x].rc,v);
		if(t[t[x].rc].pri>t[x].pri)zag(x);
	}
}
void Delete(int &x,int k)
{
	if(t[t[x].lc].size+1==k)
	{
		if(!t[x].lc||!t[x].rc)x=t[x].lc+t[x].rc;
		else if(t[t[x].lc].pri>t[t[x].rc].pri)zig(x),Delete(x,k);
		else zag(x),Delete(x,k);
		return;
	}
	t[x].size--;
	if(t[t[x].lc].size+1<k)Delete(t[x].rc,k-(t[t[x].lc].size+1));
	else Delete(t[x].lc,k);
}
/*void out(int x)
{
	if(!x)return;
	out(t[x].lc);
	printf("%d ",t[x].v);
	out(t[x].rc);
}*/
int main()
{
	freopen("one.in","r",stdin);
	freopen("one.out","w",stdout);
	srand(time(0));
	scanf("%d",&T);
	while(T--)
	{
		cnt=rt=0;
		scanf("%d",&n);
		s=0;
		for(int i=1;i<=n;i++)Insert(rt,i);
//		out(rt),puts("");
		for(int i=1;i<n;i++)
		{
			int temp=i-1;
			s=(s+temp)%(n-i+1);
			Delete(rt,s+1);
//			out(rt),puts("");
		}
		printf("%d\n",t[rt].v);
	}
//	printf("%d ms\n",(int)clock());
	return 0;
}
