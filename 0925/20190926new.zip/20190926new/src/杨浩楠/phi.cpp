#include<cstdio>
#define ll long long
#define N 10000005
using namespace std;
ll x;
int phi[N],prime[N],ans[N];
bool vis[N];
bool chk(ll x)
{
	for(int i=2;(ll)i*i<=x;i++)
		if(x%i==0)return 0;
	return 1;
}
void init()
{
	phi[1]=1,ans[1]=-1;
	for(int i=2;i<=N-5;i++)
	{
		ans[i]=-1;
		if(!vis[i])
		{
			prime[++prime[0]]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=prime[0]&&(ll)i*prime[j]<=N-5;j++)
		{
			vis[i*prime[j]]=1;
			if(i%prime[j])phi[i*prime[j]]=phi[i]*phi[prime[j]];
			else phi[i*prime[j]]=phi[i]*(phi[prime[j]]+1);
		}
	}
	for(int i=N-5;i>=1;i--)ans[phi[i]]=i;
}
int main()
{
	freopen("phi.in","r",stdin);
	freopen("phi.out","w",stdout);
	scanf("%lld",&x);
	x++;
	if(x>=(ll)1<<31)puts("-1");
	else if(chk(x))
	{
		if(x==2)puts("1");
		else printf("%lld\n",x);
	}
	else
	{
		x--;
		init();
		if(x<=(int)1e7)printf("%d\n",ans[x]);
		else puts("-1");
	}
	return 0;
}
