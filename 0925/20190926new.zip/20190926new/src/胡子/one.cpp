#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cmath>
#define re register
#define FOR(i, l, r) for(re int i = l; i <= r; ++i)
#define IT vector<int>::iterator 
using namespace std;

int n, m, c, r, t, x, y, z;
vector<int> ve;

int main() {
	freopen("one.in", "r", stdin);
	freopen("one.out", "w", stdout);
	scanf("%d", &t);
	while(t--) {
		scanf("%d", &n);
		ve.clear();
		FOR(i, 1, n)
		  ve.push_back(i);
		int now = 1, len = 0, siz = n, target = 0;
		FOR(i, 1, n-1) {
			len = i;
			if(len > siz)
			  len = (len-1)%siz+1;
			if(now+len-1 > siz)
			  target = now+len-siz-1;
			else
			  target = now+len-1;
			ve.erase(ve.begin()+target-1);
			now = (target == siz) ? 1 : target;
			--siz;		
		}
		printf("%d\n", ve[0]);
	}
}
