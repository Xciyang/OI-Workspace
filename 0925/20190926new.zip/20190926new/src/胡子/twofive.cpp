#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include <map>
#define N 2
#define maxn 50
#define re register
#define FOR(i, l, r) for(re int i = l; i <= r; ++i)
#define DFR(i, l, r) for(re int i = l; i >= r; --i)
using namespace std;

int n, m, c, r, t, x, y, z;
int cnt, num;
int a[maxn], b[maxn], thex[maxn], they[maxn]; //�ж��ѵ�ʲô�����ˡ� 
int ans[maxn][maxn];
char ch, ch1;

char _read() {
	ch1 = getchar();
	while(ch1 < 'A' || ch > 'Y')
	  ch1 = getchar();
	return ch1;
}
//
//void dfs(int x, int y) {
//	if(x == N && y == N+1) {
//		++cnt;
//		FOR(i, 1, x) {
//			FOR(j, 1, y-1)
//		      printf("%d ", ans[i][j]);
//		    cout << endl;
//		}
//		 
//		if(cnt > 100000)
//		  cnt = 0, cout << ++num;
//		return;
//	}
//	if(y == N+1) {
//		++x;
//		y = 1;
//	}
//	int st = max(thex[x], they[y])+1;
//	FOR(i, st, N*N){
////	DFR(i, N*N, st) {
//		if(b[i])  continue;
//		int __ = thex[x], ___ = they[y];
//		b[i] = 1, thex[x] = i, they[y] = i; //�ټ�¼һ��λ�á� 
//		ans[x][y] = i;
//		dfs(x, y+1);
//		b[i] = 0, thex[x] = __, they[y] = ___;
//		ans[x][y] = 0;
//	}
//} 

int main() {
	freopen("twofive.in", "r", stdin);
	freopen("twofive.out", "w", stdout);
	ch = _read();
//	dfs(1, 1);
//	cout << cnt << endl;
	if(ch == 'N') {
		scanf("%d", &n);
		if(n == 2) {
			puts("ABCDEFGHIJKLMNOPQRSUTVWXY");
		}
		else {
			puts("ABCDEFGHIJKLMNOPQRSTUVWXY");
		}
	}
	else {
		puts("2");
	}
} 
