#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#define maxn 100010 
#define re register
#define FOR(i, l, r) for(re int i = l; i <= r; ++i)
using namespace std;

int n, m, c, r, t;
int b[maxn], cnt[maxn];

int main() {
	freopen("Phi.in", "r", stdin);
	freopen("Phi.out", "w", stdout);
	scanf("%d", &n);
	if(n == 1) {
		puts("1");
		return 0;
	}
	if((n+1) %2 == 1)
	  printf("%d\n", n+1);
	else
	  puts("-1");
}
