#pragma region Header
#include <cmath>
#include <bitset>
#include <stack>
#include <map>
#include <set>
#include <queue>
#include <ctime>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
#define INF ((int)0x3F3F3F3F)
#define FINF ((int)0xC0C0C0C0)
#define llINF 0x3F3F3F3F3F3F3F3FLL
#define llFINF 0xC0C0C0C0C0C0C0C0LL
typedef long long LL;
typedef unsigned long long ULL;
typedef unsigned int UINT;
#define Clear(x) memset(v,0,sizeof(v));
#define OJ_DBG(expr,str) (void)(!!(expr)||(puts(str),exit(0),0))
#ifdef _DEBUG
#define DEBUG(str,...) fprintf(stderr,str,__VA_ARGS__)
#define DEBUGX(exp) exp
#else
#define _ASSERTE(...) (void)(0)
#define DEBUG(str,...)(int)(0)
#define DEBUGX(exp)
#endif
#define FREOPEN(s) freopen(s".in", "r", stdin); freopen(s".out", "w", stdout);
#define IGNORE() while (c > '9' || c < '0') {if (c == -1)return -1;if (c == '-')f = 0;c = getchar();}
#define READ(x,expr) while (c >= '0' && c <= '9') {expr;x = x * 10 + c - '0';c = getchar();}
inline int read() { int re = 0; bool f = 1; char c = getchar(); IGNORE(); READ(re, ;); return f ? re : -re; }
inline LL readll() { LL re = 0; bool f = 1; char c = getchar(); IGNORE(); READ(re, ;); return f ? re : -re; }
inline double readd() {
	double a = 0, b = 0; bool f = 1;
	char c = getchar();
	IGNORE(); READ(a, ;);
	if (c == '.') {
		int cnt = 0;
		c = getchar();
		READ(b, ++cnt);
		while (cnt--)b = b / 10;
	}
	return f ? (a + b) : -(a + b);
}
inline void write(LL x) {
	if (x == 0)return (void)putchar('0');
	if (x < 0)putchar('-'), x = -x;
	static char buf[30];
	char* p = buf;
	while (x) {
		*(p++) = x % 10 + '0';
		x /= 10;
	}
	while (p > buf)putchar(*(--p));
}
inline int readstr(char* s) {
	char* begin = s;
	char c = getchar();
	while (c < 32 || c > 126)c = getchar();
	while (c >= 32 && c <= 126) {
		if (c != 32)
			* (s++) = c;
		c = getchar();
	}
	*s = 0;
	return s - begin;
}
#pragma endregion


#define N 10010000
int ans[N], prime[N], phi[N];
bool vis[N];
void getphi() {
	phi[1] = vis[1] = 1;
	for (int i = 2; i < N; i++) {
		if (!vis[i]) {
			prime[++prime[0]] = i;
			phi[i] = i - 1;
		}
		for (int j = 1, k; j <= prime[0] && i * prime[j] < N; j++) {
			k = i * prime[j];
			vis[k] = 1;
			if (i % prime[j] != 0) {
				phi[k] = phi[i] * phi[prime[j]];
			} else {
				phi[k] = phi[i] * prime[j];
				break;
			}
		}
		if (ans[phi[i]] == 0)
			ans[phi[i]] = i;
	}
}
int main() {
	FREOPEN("phi");
	getphi();
	int n = read();
	printf("%d", ans[n] ? ans[n] : -1);
}

