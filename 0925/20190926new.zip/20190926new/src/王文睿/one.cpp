#pragma region Header
#include <cmath>
#include <bitset>
#include <stack>
#include <map>
#include <set>
#include <queue>
#include <ctime>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
#define INF ((int)0x3F3F3F3F)
#define FINF ((int)0xC0C0C0C0)
#define llINF 0x3F3F3F3F3F3F3F3FLL
#define llFINF 0xC0C0C0C0C0C0C0C0LL
typedef long long LL;
typedef unsigned long long ULL;
typedef unsigned int UINT;
#define Clear(x) memset(v,0,sizeof(v));
#define OJ_DBG(expr,str) (void)(!!(expr)||(puts(str),exit(0),0))
#ifdef _DEBUG
#define DEBUG(str,...) fprintf(stderr,str,__VA_ARGS__)
#define DEBUGX(exp) exp
#else
#define _ASSERTE(...) (void)(0)
#define DEBUG(str,...)(int)(0)
#define DEBUGX(exp)
#endif
#define FREOPEN(s) freopen(s".in", "r", stdin); freopen(s".out", "w", stdout);
#define IGNORE() while (c > '9' || c < '0') {if (c == -1)return -1;if (c == '-')f = 0;c = getchar();}
#define READ(x,expr) while (c >= '0' && c <= '9') {expr;x = x * 10 + c - '0';c = getchar();}
inline int read() { int re = 0; bool f = 1; char c = getchar(); IGNORE(); READ(re, ;); return f ? re : -re; }
inline LL readll() { LL re = 0; bool f = 1; char c = getchar(); IGNORE(); READ(re, ;); return f ? re : -re; }
inline double readd() {
	double a = 0, b = 0; bool f = 1;
	char c = getchar();
	IGNORE(); READ(a, ;);
	if (c == '.') {
		int cnt = 0;
		c = getchar();
		READ(b, ++cnt);
		while (cnt--)b = b / 10;
	}
	return f ? (a + b) : -(a + b);
}
inline void write(LL x) {
	if (x == 0)return (void)putchar('0');
	if (x < 0)putchar('-'), x = -x;
	static char buf[30];
	char* p = buf;
	while (x) {
		*(p++) = x % 10 + '0';
		x /= 10;
	}
	while (p > buf)putchar(*(--p));
}
inline int readstr(char* s) {
	char* begin = s;
	char c = getchar();
	while (c < 32 || c > 126)c = getchar();
	while (c >= 32 && c <= 126) {
		if (c != 32)
			* (s++) = c;
		c = getchar();
	}
	*s = 0;
	return s - begin;
}
#pragma endregion

#define N 1001000
#define LP (p<<1)
#define RP (p<<1|1)
#define LT LP,l,mid
#define RT RP,mid+1,r
int sum[N << 2];

void build(int p, int l, int r) {
	if (l == r) {
		sum[p] = 1;
		return;
	}
	int mid = (l + r) >> 1;
	build(LT); build(RT);
	sum[p] = sum[LP] + sum[RP];
}

void remove(int p, int l, int r, int x) {
	if (l == r) {
		sum[p] = 0;
		return;
	}
	int mid = (l + r) >> 1;
	if (x <= mid)remove(LT, x);
	else remove(RT, x);
	sum[p] = sum[LP] + sum[RP];
}

int kth(int p, int l, int r, int k) {
	if (l == r) {
		return l;
	}
	int mid = (l + r) >> 1;
	if (k <= sum[LP])return kth(LT, k);
	else return kth(RT, k - sum[LP]);
}
int query(int p, int l, int r, int x, int y) {
	if (l >= x && r <= y)return sum[p];
	int mid = (l + r) >> 1, ret = 0;
	if (x <= mid)ret += query(LT, x, y);
	if (y > mid)ret += query(RT, x, y);
	return ret;
}

int n;

#define GETRANK(r,siz) (((r)-1)%siz+1)

int main() {
	FREOPEN("one");
	int T = read();
	while (T--) {
		n = read();
		build(1, 1, n);
		int p = 1;
		for (int i = 1; i < n; i++) {
			int siz = n - i + 1;
			int rank = query(1, 1, n, 1, p);
			int nxtp = kth(1, 1, n, GETRANK(rank + i % siz, siz));
			p = kth(1, 1, n, GETRANK(rank + (i - 1 + siz) % siz, siz));
			remove(1, 1, n, p);
			p = nxtp;
		}
		printf("%d\n", p);
	}
	return 0;
}

