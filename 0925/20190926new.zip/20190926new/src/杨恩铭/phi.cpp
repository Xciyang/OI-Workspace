#include<cmath>
#include<cstdio>
#include<iostream>
using namespace std;
int o[20000001],phi[20000001];
int prime[2000001],n,blo;
inline void euler(){
	o[1]=phi[1]=1;
	for (int i=2; i<=blo; i++){
		if (!o[i]){
			o[i]=1; prime[++prime[0]]=i;
			phi[i]=i-1;
		}
		for (int j=1; j<=prime[0]&&prime[j]*i<=blo; j++){
			o[i*prime[j]]=1;
			if (i%prime[j]==0){
				phi[i*prime[j]]=phi[i]*prime[j];
				break;
			}
			phi[i*prime[j]]=phi[i]*phi[prime[j]];
		}
	}
}
int main(){
	freopen("phi.in","r",stdin);
	freopen("phi.out","w",stdout);
	scanf("%d",&n);
	blo=min(2e7,1.0*n*n); euler();
	int flag=0;
	for (int i=n+1; i<=blo; i++){
		if (phi[i]==n){
			printf("%d\n",i); flag=1;
			break;
		}
	}
	if (!flag) puts("-1");
	return 0;
}