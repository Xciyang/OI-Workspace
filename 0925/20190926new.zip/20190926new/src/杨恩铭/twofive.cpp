#include<cstdio>
#include<iostream>
using namespace std;
int main(){
	freopen("twofive.in","r",stdin);
	freopen("twofive.out","w",stdout);
	char ch;
	scanf("%c",&ch);
	if (ch=='N') puts("ABCDEFGHIJKLMNOPQRSUTVWXY");
	else puts("2");
	return 0;
}
