#include<bits/stdc++.h>
#define ll long long
#define gc getchar()
#define pc putchar
#define N 30000001
using namespace std;
int w,phi[N],prime[500001];
bool nopt[N];
int tot;
char o;
inline int read(){
	w=0;o=gc;
	while(!isdigit(o)) o=gc;
	while(isdigit(o)){w=(w<<1)+(w<<3)+(o^48);o=gc;}
	return w;
}
inline void write(int x){
	if(x>9) write(x/10);
	pc((x%10)^48);
}
bool f[47000];
inline bool zs(int k){
	int y=sqrt(k),j;
	for(int i=2;i<=y;i++){
		if(!f[i]){
			if(!(k%i)) return false;
			for(j=i*i;j<=y;j+=i) f[j]=1;
			f[i]=1;
		}
	}
	return true;
}
int main(){
	freopen("Phi.in","r",stdin);
	freopen("Phi.out","w",stdout);
	int x=read();
	if(x==1){pc('1');return 0;}
	if(zs(x+1)){write(x+1);return 0;}
	phi[1]=1;
	for(int i=2,k;i<N;i++){
		if(!nopt[i]){
			prime[++tot]=i;
			phi[i]=i-1;
		}
		for(int j=1;j<=tot&&(k=i*prime[j])<=N;j++){
			nopt[k]=1;
			if(!(i%prime[j])){
				phi[k]=phi[i]*prime[j];
				break;
			}
			phi[k]=phi[i]*(prime[j]-1);
		}
		if(phi[i]==x){write(i);return 0;}
	}
	pc('-'),pc('1');
	return 0;
}
