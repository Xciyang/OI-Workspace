#include<bits/stdc++.h>
#define ll long long
#define gc getchar()
#define pc putchar
#define N 10000001
using namespace std;
int w;
bool s[N];
char o;
inline int read(){
	w=0;o=gc;
	while(!isdigit(o)) o=gc;
	while(isdigit(o)){w=(w<<1)+(w<<3)+(o^48);o=gc;}
	return w;
}
inline void write(int x){
	if(x>9) write(x/10);
	pc((x%10)^48);
}
int main(){
	freopen("One.in","r",stdin);
	freopen("One.out","w",stdout);
	int n,T;
	T=read();
	ll t,g,k,p;
	for(int op=1;op<=T;op++){
		n=read();
		if(n!=1) s[1]=1;
		g=2;t=2;
		while(t<n){
			k=1;
			while(k<=t){
				if(g>n) g=2;
				if(!s[g++]) k++;
			}
			s[g-1]=1;
			t++;
		}
		for(int i=1;i<=n;i++){if(!s[i]) write(i);s[i]=0;}
		pc('\n');
	}
	return 0;
}
