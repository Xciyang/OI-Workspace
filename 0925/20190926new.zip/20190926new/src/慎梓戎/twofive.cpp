# include <cstdio>
# include <iostream>
# define R register int
# define ll long long

using namespace std;

int vis[30];
int a[6][6];
ll ans=0;

void write()
{
	for (R i=1;i<=5;++i)
	{
		for (R j=1;j<=5;++j)
			printf("%d ",a[i][j]);
		printf("\n");
	}
	printf("\n");
}

void dfs (int x,int y)
{
	if(ans>=100000) return;
    if(x==6)
		ans++;
	else
    {
        for (R i=1;i<=25;++i)
        {
            if(vis[i]) continue;
            if(i<a[x-1][y]) continue;
            if(i<a[x][y-1]) continue;
            if(i>25-(5-x+1)*(5-y+1)+1) continue;
            vis[i]=1;
            a[x][y]=i;
            if(y==5) dfs(x+1,1);
            else dfs(x,y+1);
            vis[i]=0;
        }
    }
}

int main()
{
	freopen("twofive.in","r",stdin);
	freopen("twofive.out","w",stdout);
	
    dfs(1,1);
    printf("%lld",ans);
    return 0;
}
