# include <cstdio>
# include <iostream>
# define R register int

using namespace std;

const int N=100005;
int n,t;
int nex[N],las[N];

int solve (int n)
{
    for (R i=1;i<=n;++i) nex[i]=i+1;
 	for (R i=1;i<=n;++i) las[i]=i-1;
 	las[1]=n; nex[n]=1; nex[0]=1;
    int pos=0;
    for (R i=1;i<=n-1;++i)
    {
    	pos=nex[pos];
        for (R j=1;j<=(i-1)%(n-i+1);++j)
            pos=nex[pos];
    	nex[ las[pos] ]=nex[pos];
    	las[ nex[pos] ]=las[pos];
	}
	pos=nex[pos];
	return pos;
}

int main()
{
	freopen("one.in","r",stdin);
	freopen("one.out","w",stdout);
	
	int T;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		printf("%d\n",solve(n));
	}
    return 0;
}
/*
# include <cstdio>
# include <iostream>
# include <cstring>
# define R register int

using namespace std;

const int N=10000007;
int n,t,cnt,a,b,c,d,rt;
int r[N],ch[N][2],siz[N],v[N];

inline int rand()
{
    static int seed=2003;
    return seed=int(seed*48271LL%2147483647);
}

inline void update (int x)
{
	siz[x]=1+siz[ ch[x][0] ]+siz[ ch[x][1] ];
}

int mer (int x,int y)
{
	if(x==0||y==0) return x|y;
	if(r[x]<r[y])
	{
		ch[x][1]=mer(ch[x][1],y);
		update(x); return x;
	}
	else
	{
		ch[y][0]=mer(x,ch[y][0]);
		update(y); return y;
	}
}

int newnode (int x)
{
	++cnt;
	ch[cnt][0]=ch[cnt][1]=0;
	siz[cnt]=1; v[cnt]=x; r[cnt]=rand();
	return cnt;
}

void kth (int n,int k,int &x,int &y)
{
	if(!n) { x=y=0; return; }
	if(v[n]<=k)
	{
		x=n;
		kth(ch[x][1],k,ch[x][1],y);
	}
	else
	{
		y=n;
		kth(ch[y][0],k,x,ch[y][0]);
	}
	update(n);
}

void split (int n,int k,int &x,int &y)
{
	if(!n) { x=y=0; return; }
	if(siz[ ch[n][0] ]+1<=k)
	{
		x=n;
		split(ch[x][1],k-siz[ ch[n][0] ]-1,ch[x][1],y);
	}
	else
	{
		y=n;
		split(ch[y][0],k,x,ch[y][0]);
	}
	update(n);
}

int solve (int n)
{
	if(n==1) return 1;
	cnt=0; rt=0;
	for (R i=2;i<=n;++i) 
		rt=mer(rt,newnode(i));
	int pos=1,x;
	for (R i=2;i<=n;++i)
	{
		x=i%(n-i+1);
		kth(rt,pos,a,b);
		if(x==0)
		{
			kth(a,pos-1,a,c);
			pos=v[c];
			rt=mer(a,b);
			continue;
		}
		if(siz[b]>=x)
		{
			split(b,x-1,b,c);
			split(c,1,c,d);
			pos=v[c];
			rt=mer(a,mer(b,d));
			continue;
		}
		else
		{
			x-=siz[b];
			split(a,x-1,a,c);
			split(c,1,c,d);
			pos=v[c];
			rt=mer(a,mer(d,b));
			continue;
		}
	}
	return v[rt];
}

int main()
{
	freopen("one.in","r",stdin);
	
	int T;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		printf("%d\n",solve(n));
	}
    return 0;
}
*/
