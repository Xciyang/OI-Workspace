# include <cstdio>
# include <iostream>
# define R register int
# define ll long long

using namespace std;

const int N=100;
int pri[N],h; //������ 
ll n,pans=-1,m=1LL<<32;
ll t[14],k[14];
int vis[14];
const int pr[]={0,2,7,61,709,2003};

ll qui (ll a,ll b,ll p)
{
    ll s=1; a%=p;
    while(b)
    {
        if(b&1) s=s*a%p;
		a=a*a%p;
        b>>=1;
    }
    return s;
}

bool check (ll x,ll p,ll y)
{
    ll t=qui(x,y,p);
    if(t!=1&&t!=p-1) return false;
    if(t==p-1) return true;
    if(t==1&&(y%2)) return true;
    return check(x,p,y/2);
}

bool Miller_Rabin (ll x)
{
    if(x<=1) return false;
    if(x==2||x==7||x==61||x==709) return true;
    if(check(2,x,x-1)&&check(7,x,x-1)&&check(61,x,x-1)&&check(709,x,x-1)) return true;
    return false;
}

void check1 (int h1,int h2)
{
	for (R i=1;i<=h2;++i)
	{
		int f=0;
		for (R j=1;j<=h1;++j)
			if(t[j]+1==k[i]) f=1;
		if(!f) return;
	}
	ll ans=1;
	for (R i=1;i<=h1;++i)
		if(Miller_Rabin(t[i]+1))
		{
			ans=ans*(t[i]+1);
			if(ans>=m) return;
		}
		else return;
	for (R i=1;i<=h2;++i)
	{
		ans=ans*k[i];
		if(ans>=m) return ;
	}
	if(pans==-1) pans=ans;
	pans=min(pans,ans);
}

void dfs (int x,int h1,int h2)
{
	if(pans!=-1) return;
	if(x==h+1)
		check1(h1,h2);
	else
	{
		for (R i=1;i<=h1;++i)
		{
			if(t[i]*pri[x]>=m) continue;
			t[i]*=pri[x];
			dfs(x+1,h1,h2);
			t[i]/=pri[x];
		}
		t[h1+1]=pri[x]; dfs(x+1,h1+1,h2); t[h1+1]=0;
		int f=0;
		for (R i=1;i<=h1;++i)
			if(t[i]+1==pri[x]) f=1;
		if(!f) return;
		k[h2+1]=pri[x]; dfs(x+1,h1,h2+1); k[h2+1]=0;
	}
}

int pi[1000006],vs[1000006],phi[1000006];

void init (int n)
{
	int h=0;
    phi[1]=1;
    for (R i=2;i<=n;++i)
    {
        if(!vs[i]) phi[i]=i-1,pi[++h]=i;
        for (R j=1;j<=h&&i*pi[j]<=n;++j)
        {
            vs[ i*pi[j] ]=1;
            if(i%pi[j]==0)
            {
                phi[ i*pi[j] ]=phi[i]*pi[j];
                break;
            }
            phi[ i*pi[j] ]=phi[i]*(pi[j]-1);
        }
    }
}

int main()
{
	freopen("phi.in","r",stdin);
	freopen("phi.out","w",stdout);
	
	scanf("%lld",&n);
	init(1000000);
	for (R i=1;i<=1000000;++i)
		if(phi[i]==n)
		{
			printf("%d\n",i);
			return 0;
		}
	for (R i=2;1LL*i*i<=n;++i)
	{
		if(n%i) continue;
		while(n%i==0) pri[++h]=i,n/=i;	
	}
	if(n!=1) pri[++h]=n;
	dfs(1,0,0);
	printf("%lld",pans);
    return 0;
}
