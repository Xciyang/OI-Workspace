#include <iostream>
#include <cstdio>
#include <string>

using namespace std;
string x;
int main()
{
	freopen("twofive.in","r",stdin);
	freopen("twofive.out","w",stdout);
	cin >> x;
	if(x == "N") cout << "ABCDEFGHIJKLMNOPQRSUTVWXY" << endl;
	else if(x == "W") cout << 2 << endl;
	return 0;
}
