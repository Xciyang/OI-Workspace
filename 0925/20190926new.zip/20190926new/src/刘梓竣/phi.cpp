#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int prime[1000005], cnt, phi[15000005];
bool vis[15000005];
void sieve(int N)
{
    for (int i = 2; i <= N; i++)
    {
        if (!vis[i]) prime[++cnt] = i, phi[i] = i - 1;
        for (int j = 1; j <= cnt && i * prime[j] <= N; j++)
        {
            vis[i * prime[j]] = 1;
            if (i % prime[j] == 0)
            {
                phi[i * prime[j]] = phi[i] * prime[j];
                break;
            }
            phi[i * prime[j]] = phi[i] * (prime[j] - 1);
        }
    }
}
int main()
{
    freopen("phi.in","r",stdin);
    freopen("phi.out","w",stdout);
    int n, f;
    cin >> n;
    sieve(15000000);
    for(int i = 1; i <= 15000000; i++)
        if(phi[i] == n)
    {
        printf("%d\n", i); f=1; break;
    }
    if(!f) printf("-1\n");
    return 0;
}
