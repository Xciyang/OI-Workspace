#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int N=1000100,inf=2147483647;
int n,m,flag[N],prime[N],cnt;
long long ans=1;
inline int read(){
    int sym=0,res=0;char ch=0;
    while (ch<'0'||ch>'9')sym|=(ch=='-'),ch=getchar();
    while (ch>='0'&&ch<='9')res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
    return sym?-res:res;
}
void file(){
    freopen("phi.in","r",stdin);
    freopen("phi.out","w",stdout);
}
void init(){
    for (int i=2;i<=n+1;i++){
        if (!flag[i]){
            prime[++cnt]=i;
        }
        for (int j=1;j<=cnt&&i*prime[j]<=n+1;j++){
            flag[i*prime[j]]=1;
            if (i%prime[j]==0)break;
        }
    }
}
bool cal(int x){
    ans=1ll*ans*x;if (ans>=inf)return 1;return 0;
}
int main(){file();
    n=read();init();
    for (int i=cnt;i>=2;i--){
        if (n%(prime[i]-1)==0){
            n/=(prime[i]-1);
            if (cal(prime[i])){printf("-1");return 0;}
            while (n%prime[i]==0){
                n/=prime[i];
                if (cal(prime[i])){printf("-1");return 0;}
            }
        }
    }
    while (n&1==0){
        n>>=1;
        if (cal(2)){printf("-1");return 0;}
    }
    if (ans==1)printf("-1");
    else printf("%lld",ans);
    return 0;
}