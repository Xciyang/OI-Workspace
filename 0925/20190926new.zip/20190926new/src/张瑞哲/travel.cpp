#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int N=200010;
int n,l,s,a[N];
inline int read(){
    int sym=0,res=0;char ch=0;
    while (ch<'0'||ch>'9')sym|=(ch=='-'),ch=getchar();
    while (ch>='0'&&ch<='9')res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
    return sym?-res:res;
}
void file(){
    freopen("travel.in","r",stdin);
    freopen("travel.out","w",stdout);
}
int main(){file();
    n=read();l=read();s=read();
    int flag=1;
    for (int i=1;i<=n;i++){
        a[i]=read();if (a[i]!=i)flag=0;
    }
    if (l==n-1){
        if (s!=n){
            printf("-1");return 0;
        }else{
            int ans=0;
            for (int i=n;i>=2;i--){
                ans+=abs(a[i]-a[i-1]);
            }printf("%d",ans);
            for (int i=n-1;i>=1;i--){
                printf("%d ",i);
            }return 0;
        }
    }
    if (flag){
        if (l<=s-1){
            printf("%d\n",n+s-2);
            for (int i=s-1;i>=s-l+1;i--)printf("%d ",i);
            printf("1 ");
            for (int i=2;i<=s-l;i++)printf("%d ",i);
            for (int i=s+1;i<=n;i++)printf("%d ",i);
            return 0;
        }
    }
    return 0;
}