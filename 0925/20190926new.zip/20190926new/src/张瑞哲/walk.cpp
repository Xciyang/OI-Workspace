#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <queue>
using namespace std;
const int N=1010;
struct EDGE{
    int ver,nxt,dis;
}edge[N];
int n,m,head[N],len[N][N],f[N][N],cnt,ans[N];
inline int read(){
    int sym=0,res=0;char ch=0;
    while (ch<'0'||ch>'9')sym|=(ch=='-'),ch=getchar();
    while (ch>='0'&&ch<='9')res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
    return sym?-res:res;
}
void file(){
    freopen("walk.in","r",stdin);
    freopen("walk.out","w",stdout);
}
void add(int u,int v,int t){
    edge[++cnt].ver=v;
    edge[cnt].nxt=head[u];
    edge[cnt].dis=t;
    head[u]=cnt;
}
int gcd(int a,int b){
    return !b?a:gcd(b,a%b);
}
void dfs(int now,int u,int fa){
    for (int i=head[u];i;i=edge[i].nxt){
        int v=edge[i].ver;
        if (v==fa)continue;len[now][v]=len[now][u]+1;
        if (now==u)f[now][v]=edge[i].dis;
        else f[now][v]=gcd(f[now][u],edge[i].dis);
        dfs(now,v,u);
    }
}
int main(){file();
    n=read();
    for (int i=1;i<=n-1;i++){
        int x=read(),y=read(),t=read();add(x,y,t);add(y,x,t);
    }
    for (int i=1;i<=n;i++){
        dfs(i,i,0);
    }
    for (int i=1;i<=n;i++){
        for (int j=1;j<=n;j++){
            if (i==j)continue;
            ans[len[i][j]]=max(ans[len[i][j]],f[i][j]);
        }
    }
    for (int i=1;i<=n;i++){
        printf("%d\n",ans[i]);
    }
    return 0;
}