#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <queue>
#define int long long
using namespace std;
const int N=100010;
int n,m,dp[N];
inline int read(){
    int sym=0,res=0;char ch=0;
    while (ch<'0'||ch>'9')sym|=(ch=='-'),ch=getchar();
    while (ch>='0'&&ch<='9')res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
    return sym?-res:res;
}
void file(){
    freopen("read.in","r",stdin);
    freopen("write.out","w",stdout);
}
int gcd(int a,int b){
    return !b?a:gcd(b,a%b);
}
int cal(int a){
    return a*(a-1)>>1;    
}
signed main(){
    int T=read();
    while (T--){
        n=read();m=read();if (n>m)swap(n,m);
        int q=read(),ans=q,d=gcd(m,n),lcm=n/gcd(m,n)*m;
        for (int i=0;i*n<=q;i++){
            ans-=d;
        }printf("%lld\n",ans);
    }return 0;
}