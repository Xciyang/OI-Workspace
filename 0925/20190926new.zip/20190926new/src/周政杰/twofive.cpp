#pragma region revive
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <algorithm>
#define inl inline
#define re register int
#define fa(x) t[a].fa
#define son(x, y) t[a].child[y]
#define ls(x) t[a].child[0]
#define rs(x) t[a].child[1]
#define ll long long
const int inf = 0x3f3f3f3f;
#define lowbit(x) ((a) & (-a))
using namespace std;
//#ifndef _DEBUG
//#define getchar() (*(IOB.in.p++))
//#define putchar(c) (*(IOB.out.p++) = (c))
//#define io_eof() (IOB.in.p >= IOB.in.pend)
//struct IOBUF {
//	struct {
//		char buff[1 << 27], *p, *pend;
//	} in;
//	struct {
//		char buff[1 << 27], *p;
//	} out;
//	IOBUF() {
//		in.p = in.buff;
//		out.p = out.buff;
//		in.pend = in.buff + fread(in.buff, 1, 1 << 27, stdin);
//	}
//	~IOBUF() { fwrite(out.buff, 1, out.p - out.buff, stdout); }
//} IOB;
//#endif
template <typename IO>
inl void write(IO x) {
	if (x == 0) return (void)putchar('0');
	if (x < 0) putchar('-'), x = -x;
	static char buf[30];
	char *p = buf;
	while (x) {
		*(p++) = x % 10 + '0';
		x /= 10;
	}
	while (p > buf)
		putchar(*(--p));
}
inl void writestr(const char *s) {
	while (*s != 0)
		putchar(*(s++));
}
template <typename IO>
inl void writeln(IO x) { write(x), putchar('\n'); }
template <typename IO>
inl void writesp(IO x) { write(x), putchar(' '); }
inl int readstr(char *s) {
	char *begin = s, c = getchar();
	while (c < 33 || c > 127) {
		c = getchar();
	}
	while (c >= 33 && c <= 127) {
		*(s++) = c;
		c = getchar();
	}
	*s = 0;
	return s - begin;
}
template <typename IO>
inl IO read() {
	IO x = 0;
	register bool w = 0;
	register char c = getchar();
	while (c > '9' || c < '0') {
		if (c == '-') w = 1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	return w ? -x : x;
}
template <>
inl double read<double>() {
	double x = 0;
	int w = 0, y = 0;
	ll z = 1;
	register char c = getchar();
	while (c > '9' || c < '0') {
		if (c == '-') w = 1;
		c = getchar();
	}
	while (c >= '0' && c <= '9' || c == '.') {
		if (c == '.') {
			y = 1, c = getchar();
			continue;
		}
		x = x * 10 + (c ^ 48);
		if (y) z *= 10;
		c = getchar();
	}
	return (w ? -x : x) / z;
}
#pragma endregion
char a[16][16], s[32];
int num, cnt;
bool vis[32], flag;
inl void dfs1(int x, int y) {
	if (flag)return;
	if (x > 5) {
		++cnt;
		if (cnt == num) {
			for (re i = 1; i <= 5; i++) {
				for (re j = 1; j <= 5; j++) {
					s[(i - 1) * 5 + j - 1] = 'A' - 1 + a[i][j];
				}
			}
			flag = 1;
		}
		return;
	}
	for (re c = max(a[x][y - 1], a[x - 1][y]) + 1; c <= 25; c++) {
		if (vis[c])continue;
		vis[c] = 1;
		a[x][y] = c;
		if (y == 5)dfs1(x + 1, 1);
		else dfs1(x, y + 1);
		vis[c] = 0;
	}
}
inl void dfs2(int x, int y) {
	if (flag)return;
	if (x > 5) {
		++cnt;
		for (re i = 1; i <= 5; i++) {
			for (re j = 1; j <= 5; j++) {
				if (s[(i - 1) * 5 + j - 1] != 'A' - 1 + a[i][j])return;
			}
		}
		flag = 1;
		return;
	}
	for (re c = max(a[x][y - 1], a[x - 1][y]) + 1; c <= 25; c++) {
		if (vis[c])continue;
		vis[c] = 1;
		a[x][y] = c;
		if (y == 5)dfs2(x + 1, 1);
		else dfs2(x, y + 1);
		vis[c] = 0;
	}
}
int main() {
	freopen("twofive.in", "r", stdin);
	freopen("twofive.out", "w", stdout);
	char op[2];
	readstr(op);
	if (op[0] == 'N') {
		num = read<int>(), dfs1(1, 1), writestr(s);
	}
	else {
		readstr(s), dfs2(1, 1), writeln(cnt);
	}
	return 0;
}
