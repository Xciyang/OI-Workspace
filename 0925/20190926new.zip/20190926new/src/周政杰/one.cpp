#pragma region revive
#include <set>
#include <map>
#include <cmath>
#include <queue>
#include <stack>
#include <bitset>
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <algorithm>
#define inl inline
#define re register int
#define fa(x) t[x].fa
#define son(x, y) t[x].child[y]
#define ls(x) t[x].child[0]
#define rs(x) t[x].child[1]
#define ll long long
const int inf = 0x3f3f3f3f;
#define lowbit(x) ((x) & (-x))
using namespace std;
//#ifndef _DEBUG
//#define getchar() (*(IOB.in.p++))
//#define putchar(c) (*(IOB.out.p++) = (c))
//#define io_eof() (IOB.in.p >= IOB.in.pend)
//struct IOBUF {
//	struct {
//		char buff[1 << 27], *p, *pend;
//	} in;
//	struct {
//		char buff[1 << 27], *p;
//	} out;
//	IOBUF() {
//		in.p = in.buff;
//		out.p = out.buff;
//		in.pend = in.buff + fread(in.buff, 1, 1 << 27, stdin);
//	}
//	~IOBUF() { fwrite(out.buff, 1, out.p - out.buff, stdout); }
//} IOB;
//#endif
template <typename IO>
inl void write(IO x) {
	if (x == 0) return (void)putchar('0');
	if (x < 0) putchar('-'), x = -x;
	static char buf[30];
	char *p = buf;
	while (x) {
		*(p++) = x % 10 + '0';
		x /= 10;
	}
	while (p > buf)
		putchar(*(--p));
}
inl void writestr(const char *s) {
	while (*s != 0)
		putchar(*(s++));
}
template <typename IO>
inl void writeln(IO x) { write(x), putchar('\n'); }
template <typename IO>
inl void writesp(IO x) { write(x), putchar(' '); }
inl int readstr(char *s) {
	char *begin = s, c = getchar();
	while (c < 33 || c > 127) {
		c = getchar();
	}
	while (c >= 33 && c <= 127) {
		*(s++) = c;
		c = getchar();
	}
	*s = 0;
	return s - begin;
}
template <typename IO>
inl IO read() {
	IO x = 0;
	register bool w = 0;
	register char c = getchar();
	while (c > '9' || c < '0') {
		if (c == '-') w = 1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		x = (x << 3) + (x << 1) + (c ^ 48);
		c = getchar();
	}
	return w ? -x : x;
}
template <>
inl double read<double>() {
	double x = 0;
	int w = 0, y = 0;
	ll z = 1;
	register char c = getchar();
	while (c > '9' || c < '0') {
		if (c == '-') w = 1;
		c = getchar();
	}
	while (c >= '0' && c <= '9' || c == '.') {
		if (c == '.') {
			y = 1, c = getchar();
			continue;
		}
		x = x * 10 + (c ^ 48);
		if (y) z *= 10;
		c = getchar();
	}
	return (w ? -x : x) / z;
}
#pragma endregion
int t[4000001];
inl void build(int k, int l, int r) {
	if (l == r) { t[k] = 1; return; }
	re mid = l + r >> 1;
	build(k << 1, l, mid), build(k << 1 | 1, mid + 1, r);
	t[k] = t[k << 1] + t[k << 1 | 1];
}
inl void del(int k, int l, int r, int p) {
	if (l == r) { t[k] = 0; return; }
	re mid = l + r >> 1;
	if (p <= mid)del(k << 1, l, mid, p);
	else del(k << 1 | 1, mid + 1, r, p);
	t[k] = t[k << 1] + t[k << 1 | 1];
}
inl int getrk(int k, int l, int r, int w) {
	if (l == r)return l;
	re mid = l + r >> 1;
	if (t[k << 1] >= w)return getrk(k << 1, l, mid, w);
	else return getrk(k << 1 | 1, mid + 1, r, w - t[k << 1]);
}
inl int query(int k, int l, int r, int x, int y) {
	if (l >= x && r <= y)return t[k];
	int mid = (l + r) >> 1, ret = 0;
	if (x <= mid)ret += query(k << 1, l, mid, x, y);
	if (y > mid)ret += query(k << 1 | 1, mid + 1, r, x, y);
	return ret;
}
signed main() {
	freopen("one.in", "r", stdin);
	freopen("one.out", "w", stdout);
	re T = read<int>();
	while (T--) {
		re n = read<int>(), w = 1;
		build(1, 1, n);
		for (re i = 1; i < n; i++) {
			re p = n - i + 1, rk = query(1, 1, n, 1, w), nxt = getrk(1, 1, n, (rk + i % p - 1) % p + 1);
			w = getrk(1, 1, n, (rk + (i - 1 + p) % p - 1) % p + 1);
			del(1, 1, n, w);
			w = nxt;
		}
		writeln(w);
	}
}
