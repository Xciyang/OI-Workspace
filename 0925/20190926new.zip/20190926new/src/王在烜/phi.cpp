#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define re register
#define LL long long
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
const int M=1.5e7+5;
bool f[M+1];
int phi[M+1],p[M>>1];
int n;
int main() {
	freopen("phi.in","r",stdin);
	freopen("phi.out","w",stdout);
	scanf("%d",&n);phi[1]=1;
	for(re int i=2;i<=M;++i) {
		if(!f[i]) p[++p[0]]=i,phi[i]=i-1;
		if(phi[i]==n) return printf("%d\n",i),0;
		for(re int j=1;j<=p[0]&&p[j]*i<=M;++j) {
			f[p[j]*i]=1;
			if(i%p[j]==0) {
				phi[p[j]*i]=p[j]*phi[i];
				break;
			}
			phi[p[j]*i]=(p[j]-1)*phi[i];
		}
	}
	return puts("-1"),0;
}

