#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define re register
int T,n;
int main() {
	freopen("one.in","r",stdin);
	freopen("one.out","w",stdout);
	scanf("%d",&T);
	while(T--) {
		scanf("%d",&n);
		int ans=0;
		for(re int i=n-1;i>=1;--i) {
			int now=ans+1;
			int len=n-i+1;
			int pos=(1-i+len)%len;
			ans=(now-pos+len)%len;	
		}
		printf("%d\n",ans+1);
	}
	return 0;
}
/*
1
10000000
*/
