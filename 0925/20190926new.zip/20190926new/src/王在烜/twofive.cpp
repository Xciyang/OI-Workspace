#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#define re register
#define LL long long
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
inline int read() {
	char c=getchar();int x=0;while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9') x=(x<<3)+(x<<1)+c-48,c=getchar();return x;
}
const int maxn=3e3+5;const int mod=998244353;
char op[6];
struct SAM {
	int len[maxn],A[maxn],tax[maxn>>1],fa[maxn],son[maxn][26],sz[maxn];
	int cnt,lst,n;
	char S[maxn>>1];
	inline void ins(int c) {
		int p=++cnt,f=lst;lst=p;len[p]=len[f]+1;sz[p]=1;
		while(f&&!son[f][c]) son[f][c]=p,f=fa[f];
		if(!f) {fa[p]=1;return;}int x=son[f][c];
		if(len[f]+1==len[x]) {fa[p]=x;return;}int y=++cnt;
		len[y]=len[f]+1,fa[y]=fa[x],fa[x]=fa[p]=y;
		for(re int i=0;i<26;++i) son[y][i]=son[x][i];
		while(f&&son[f][c]==x) son[f][c]=y,f=fa[f];
	}
	inline void solve() {
		scanf("%s",S+1);for(re int i=1;i<=n;i++) ins(S[i]-'a');
		for(re int i=1;i<=cnt;++i) tax[len[i]]++;
		for(re int i=1;i<=n;i++) tax[i]+=tax[i-1];
		for(re int i=cnt;i;--i) A[tax[len[i]]--]=i;
		for(re int i=cnt;i;--i) {
			int x=A[i];
			sz[fa[x]]+=sz[x];
		}
	}
	inline void clr() {
		for(re int i=1;i<=cnt;++i) fa[i]=sz[i]=len[i]=0;
		for(re int i=1;i<=cnt;++i) 
			for(re int j=0;j<26;++j) son[i][j]=0;
		cnt=lst=1;
	}
}S;
inline int qm(int a) {return a>=mod?a-mod:a;}
inline int ksm(int a,int b) {int S=1;for(;b;b>>=1,a=1ll*a*a%mod) if(b&1) S=1ll*S*a%mod;return S;}
namespace Calc1 {inline void solve() {printf("%d\n",ksm(2,1));}}
namespace Ddffss{
	int ans=0;int s[1005],n;
	inline int chk(int n) {
		S.clr();S.solve();
		int now=0;
		for(re int i=2;i<=n;i++)
			now+=(S.len[i]==s[i]+s[i-1]);
		for(re int i=1;i<=n-1;++i)
			now+=(S.len[i]==s[i+1]+s[i]);
		return now;  
	}
	void dfs(int x,int y,int now,int etp) {
		if(x==6) {ans+=chk(now);return;}
		int nx,ny;
		if(y==5) nx=x+1,y=1;
		else nx=x,ny=y+1; 
		for(re int i=0;i<26;++i) { 
			s[now]=i;
			dfs(nx,ny,now+1,etp);
		}
	}
}
namespace Calc2 {
	struct ntt{
		inline int dqm(int a) {return a<0?a+mod:a;}
		int G[2],rev[maxn],len;
		inline void NTT(int *f,int o) {
			for(re int i=0;i<len;i++) rev[i]=rev[i>>1]>>1|((i&1)?len>>1:0);
			for(re int i=0;i<len;i++) if(i<rev[i]) std::swap(f[i],f[rev[i]]);
			for(re int i=2;i<=len;i<<=1) {
				int ln=i>>1,og1=ksm(G[o],(mod-1)/i);
				for(re int t,og=1,l=0;l<len;l+=i,og=1)
					for(re int x=l;x<l+ln;++x) {
						t=1ll*og*f[x+ln]%mod,og=1ll*og*og1%mod;
						f[x+ln]=dqm(f[x]-t),f[x]=qm(f[x]+t);
					}
			}
			if(!o) return;
			int Inv=ksm(len,mod-2);
			for(re int i=0;i<len;i++) f[i]=1ll*f[i]*Inv%mod;
		}
	}H;
	inline int solve() {
		H.G[0]=3,H.G[1]=(mod+1)/3;
		return puts("ABCDEFGHIJKLMNOPQRSUTVWXY"),0;
		Ddffss::dfs(1,1,0,0);
	}
}
namespace Segment_Tree {
	int l[maxn<<2],r[maxn<<2],sum[maxn<<2],tag[maxn<<2];
	void build(int x,int y,int i) {
		l[i]=x,r[i]=y;
		if(x==y) return;
		int mid=x+y>>1;
		build(x,mid,i<<1),build(mid+1,y,i<<1|1);
	}
	inline void pushdown(int i){tag[i]=0;}
	void change(int x,int y,int v,int i) {
		if(x<=l[i]&&y>=r[i]) {
			tag[i]=v;
			sum[i]=(r[i]-l[i]+1)*v;
			return;
		}
		pushdown(i);
		int mid=l[i]+r[i]>>1;
		if(x<=mid) change(x,y,v,i<<1);
		if(y>mid) change(x,y,v,i<<1|1);
	} 
}
signed main() {
	freopen("twofive.in","r",stdin);
	freopen("twofive.out","w",stdout);
	scanf("%s",op+1);
	if(op[1]=='W') return Calc1::solve(),0;
		return Calc2::solve();
	return 0;
}
