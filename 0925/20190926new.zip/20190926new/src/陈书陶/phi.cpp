#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

#define maxn 20000001
#define inf 0x3f3f3f3f
#define pn putchar('\n')
#define px(x) putchar(x)
#define ps putchar(' ')
#define pd printf("======================")
#define pj printf("++++++++++++++++++++++")

using namespace std;

inline int read(){
	int x=0,y=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')y=1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return y?-x:x;
}
template<typename T>
inline T read(){
	T x=0;
	int y=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')y=1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return y?-x:x;
}
int prime[2000005],phi[maxn],cnt;
bool is[maxn];
int main(){
	freopen("phi.in","r",stdin);
	freopen("phi.out","w",stdout);
	int x=read();
	if(x&1){puts("-1");return 0;}
	phi[1]=1;
	for(register int i=2;i<maxn;++i){
		if(!is[i])prime[++cnt]=i,phi[i]=i-1;
		for(register int j=1;j<=cnt&&i*prime[j]<maxn;++j){
			is[i*prime[j]]=1;
			if(i%prime[j])phi[i*prime[j]]=phi[i]*(prime[j]-1);
			else {
				phi[i*prime[j]]=phi[i]*prime[j];
				break;
			}
		}
	}
	for(register int i=1;i<maxn;++i)
		if(phi[i]==x){
			printf("%d\n",i);
			return 0;
		}
	puts("-1");
}
