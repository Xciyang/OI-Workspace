#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

#define maxn 100005
#define inf 0x3f3f3f3f
#define pn putchar('\n')
#define px(x) putchar(x)
#define ps putchar(' ')
#define pd printf("======================")
#define pj printf("++++++++++++++++++++++")

using namespace std;

inline int read(){
	int x=0,y=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')y=1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return y?-x:x;
}
template<typename T>
inline T read(){
	T x=0;
	int y=0;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')y=1;ch=getchar();}
	while(ch>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return y?-x:x;
}
string s;
int main(){
	freopen("twofive.in","r",stdin);
	freopen("twofive.out","w",stdout);
	char tp[3];
	scanf("%s",tp);
	if(tp[0]=='N'){
		int x=read();
		if(x==1)puts("ABCDEFGHIJKLMNOPQRSTUVWXY");
		else if(x==2)puts("ABCDEFGHIJKLMNOPQRSUTVWXY");
		else puts("ACEPTBDHQUFJMRWGKNSXILOVY");
	} 
	else {
		cin>>s;
		if(s=="ABCDEFGHIJKLMNOPQRSTUVWXY")puts("1");
		else if(s=="ABCDEFGHIJKLMNOPQRSUTVWXY")puts("2");
		else puts("5");
	}
}
