#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>

using namespace std;

int a[11],n,m,c[10][10],res,f[6][6][6][6][6];
char C,d[101][101],g[1001];
void dfs(int S)
{
	if(f[a[1]][a[2]][a[3]][a[4]][a[5]]) return ;
	int s=0;
	for(int i=1;i<=5;i++) if(a[i] && a[i]!=a[i+1])
	{
		a[i]-=1;dfs(S-1); 
		s+=f[a[1]][a[2]][a[3]][a[4]][a[5]]; 
		a[i]+=1;
	}
	f[a[1]][a[2]][a[3]][a[4]][a[5]]=s;
}

void dfs_(int s,int S)
{
	if(S==1) return ;
	for(int i=5;i>=1;i--) if(a[i] && a[i]!=a[i+1])
	{
		a[i]-=1;
		if(f[a[1]][a[2]][a[3]][a[4]][a[5]]>=s) 
		{
			c[i][a[i]+1]=26-S;
			return dfs_(s,S-1);
		}
		s-=f[a[1]][a[2]][a[3]][a[4]][a[5]];
		a[i]+=1;
	}
}

int ask(int S)
{
	int k=0;
	if(S==25) return 0;
	for(int i=5;i>=1;i--) if(a[i] && a[i]!=a[i+1])
	{
		a[i]-=1;
		if(c[5-i+1][5-a[i]]==S) return k+ask(S+1);
		k+=f[a[1]][a[2]][a[3]][a[4]][a[5]];
		a[i]+=1;
	}
}
int main()
{
	freopen("twofive.in","r",stdin);
	freopen("twofive.out","w",stdout);
	scanf("%c",&C);
	if(C=='N')
	{
		scanf("%d",&n);
		f[a[1]][a[2]][a[3]][a[4]][a[5]]=1;
		for(int i=1;i<=5;i++) a[i]=5;
			for(int j=1;j<=5;j++) 
		dfs(25);
		for(int i=1;i<=4;i++) a[i]=5;
		a[5]=4; c[5][5]=1, c[1][1]=25;
		dfs_(n,24);
		for(int i=5;i>=1;i--)
			for(int j=5;j>=1;j--) 
				printf("%c",c[i][j]-1+'A');
	}
	else 
	{
		for(int i=1;i<=5;i++)
			for(int j=1;j<=5;j++)
			{
				scanf("%c",&d[i][j]);
				while(d[i][j]<'A' || d[i][j]>'Z') scanf("%c",&d[i][j]);
				c[i][j]=d[i][j]-'A'+1;
			}
		f[a[1]][a[2]][a[3]][a[4]][a[5]]=1;
		for(int i=1;i<=5;i++) a[i]=5;
		dfs(25);
		for(int i=1;i<=4;i++) a[i]=5;
		a[5]=4;
		printf("%d",1+ask(2));
	}
}
