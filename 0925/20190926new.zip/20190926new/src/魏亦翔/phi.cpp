#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>
#include<cmath>
#define LL long long 
using namespace std;

const int M = 1100001;
int n,m,k,a[M],p[M],cnt,b[M],phi[M],w[M];
LL res=1000000000000ll,ans=1;
int check(int x)
{
	int t=sqrt(x);
	for(int i=2;i<=t;i++) if(x%i==0) return 0;
	return 1;
}

int main()
{
	freopen("phi.in","r",stdin);
	freopen("phi.out","w",stdout);
	scanf("%d",&n); m=sqrt(n+1); int x=n;
	if(n==1)
	{
		printf("1");
		return 0;
	}
	if(check(n+1)) 
	{
		printf("%d",n+1);
		return 0;
	}
	
	for(int i=2;i<=1000000;i++)
	{
		if(!b[i]) p[++cnt]=i,phi[i]=i-1;
		for(int j=1;j<=cnt && p[j]*i<=1000000;j++)
		{
			b[i*p[j]]=1;
			if(i%p[j]==0)
			{
				phi[i*p[j]]=phi[i]*p[j];
				break;
			}
			phi[i*p[j]]=phi[i]*(p[j]-1);
		}
		if(!w[phi[i]]) w[phi[i]]=i;
	}
	
	n=n;
	
	if(n<=1000000 && w[n])
	{
		printf("%d",w[n]);
		return 0;
	}
	
	for(int i=1;i<=m;i++) if(w[i]&& n%i==0)
	{
		if(check(n/i+1)) res=min(res,(LL)w[i]*(n/i+1));
	}
	
	for(int i=cnt;i>=1;i--) if(x%(p[i]-1)==0) 
	{
		x/=p[i]-1; ans=ans*p[i];
		if(ans>=(1ll<<31)) 
		{ 
			if(res<(1ll<<31)) printf("%lld",res);
			else printf("-1\n");
			return 0;
		}
		while(x%p[i]==0) 
		{
			x/=p[i];
			ans*=(LL)p[i];
			if(ans>=(1ll<<31)) 
			{
				if(res<(1ll<<31)) printf("%lld",res);
				else printf("-1\n");
				return 0;
			}
		}
	}
	if(x!=1) 
	{
		if(res<(1ll<<31)) printf("%lld",res);
		else printf("-1\n");
	}
	else printf("%lld",min(res,ans));
}

