#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>

using namespace std;

const int M = 100001;
int n,m,k,a[M],T;

int main()
{
	freopen("one.in","r",stdin);
	freopen("one.out","w",stdout);
	scanf("%d",&T);
	for(;T;T--)
	{
		scanf("%d",&n); int t=1, m=1; 
		for(int i=n-1;i>=1;i--)
		{
			t++;
			int k=i%t+1;
			if(!k) k=t;
			m=(m-1+k)%t;
			if(!m) m=t;
		}
		printf("%d\n",m);
	}
}
