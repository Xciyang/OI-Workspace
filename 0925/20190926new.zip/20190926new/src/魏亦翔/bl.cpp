#include<iostream>
#include<cstring>
#include<cstdio>

using namespace std;

int n,m,k,T,a[10001];

int main()
{
	scanf("%d",&T);
	for(;T;T--)
	{
		scanf("%d",&n); int k=0;
		for(int i=1;i<n;i++)
		{
		
			for(int j=1;j<=i;j++)
			{
				k+=1;
				if(k%n==1) k=1;
				while(a[k]) 
				{
					k++;
					if(k%n==1) k=1;
				}
				
			}
			a[k]=1;
		}
		for(int i=1;i<=n;i++) if(!a[i]) printf("%d\n",i);
		memset(a,0,sizeof(a));
	}
}
