#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
const int N = 2147483647;
const int M = 4e6;
int x,vis[M + 5],prime[M + 5],cnt,phi[M + 5];
using namespace std;
void make()
{
    vis[1] = 1;
    phi[1] = 1;
    for (int i = 2;i <= M;i++)
    {
        if (!vis[i])
        {
            phi[i] = i - 1;
            prime[++cnt] = i;
        }
        for (int j = 1;j <= cnt && prime[j] * i <= M;j++)
            if (i % prime[j] == 0)
            {
                vis[prime[j] * i] = 1;
                phi[i * prime[j]] = phi[i] * prime[j];
                break;
            }
            else
            {
                vis[prime[j] * i] = 1;
                phi[i * prime[j]] = phi[i] * phi[prime[j]];
            }
    }
}
int main()
{

    freopen("Phi.in","r",stdin);
    freopen("Phi.out","w",stdout);

    scanf("%d",&x);
    make();
    long long now = x + 1;
    long long t = sqrt(now);
    int fl = 1;
    for (long long i = 2;i <= t;i++)
        if (now % i == 0)
        {
            fl = 0;
            break;
        }
    if (fl)
        printf("%lld",now);
    else
    {
        int f = 0;
        for (int i = 1;i <= M;i++)
            if (phi[i] == x)
            {
                printf("%d",i);
                f = 1;
                break;
            }
        if (!f)
            printf("-1");
    }
    return 0;
}