#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
const int N = 10000;
using namespace std;
int T,n,a[N + 5],vis[N + 5];
int main()
{
    
    freopen("One.in","r",stdin);
    freopen("One.out","w",stdout);
    
    scanf("%d",&T);
    while(T--)
    {
        memset(vis,0,sizeof(vis));
        scanf("%d",&n);
        n++;
        int last = 0,num = 0;
        for (int i = 1;i < n;i++)
        {
            while (num < i)
            {
                last = last % n + 1;
                if (!vis[last])
                    num++;
            }
            vis[last] = 1;
            num = 0;
        }
        for (int i = 1;i <= n;i++)
            if (!vis[i])
            {
                printf("%d\n",i);
                break;
            }
    }
    return 0;
}